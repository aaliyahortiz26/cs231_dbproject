﻿
// IMPORTANT!!! Right click your solution file >> Manage NuGet Packages... >> And install MySQL.Data by Oracle


/*
 This program will ask for the users username and password, and check if it exists in the table
if not, then create new account, else sign in.
Then, display all of the products, let the user choose a product and the quantity,
confirm price. then continue shopping until -1 is chosen.
Then print receipt, put the date of transaction, and store the invoice in database
 */

using System;
using MySql.Data.MySqlClient; // Import Statement for connecting C# to MySQL client
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS231_project_test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Four variables to create the connection string
            string server = "localhost"; // If not using a cloud database, use localhost. If using cloud database, use the IP to the server
            string database = "online_store"; // Whatever database you want use for the application
            string username = "root"; // The username of your MySQL client
            string password = "PWL622002!"; // The password of your MySQL client

            // Throw all the variables into this connection string
            // MUST USE THIS FORMAT! (server, database, username, then password)
            string connstring = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + username + ";" + "PASSWORD=" + password + ";";

            // integers for users to select options in the switch statement at the beginning and end of the program
            int userSelection = 0;
            int continueShopping = -1;

            double total_price = 0;

            string user_username = "";
            string user_password = "";
            string user_fname = "";
            string user_lname = "";
            string user_email = "";

            // this bool will be used when validating if the username and password are correct
            // because then the users can continue the program
            bool hasAccess = false;

            // Initializes the query string to be used for when you GET POST or DELETE
            string query;

            // Initializes the connection object called "conn", using the connection string
            MySqlConnection conn = new MySqlConnection(connstring);

            // Initializes the command object called "cmd"
            MySqlCommand cmd;

            // Initializes the reader objected called "reader"
            MySqlDataReader reader;

            Console.WriteLine("Enter:\n\t1 - Login (Returning User)\n\t2 - Register\n");

            do {
                userSelection = Convert.ToInt32(Console.ReadLine());
            } while (userSelection != 1 && userSelection != 2);
            
    
            switch (userSelection) {
                case 1:
                    // if hasaccess is false then this loop will continue until
                    // the user gets the username right and can continue on
                    do
                    {
                        Console.WriteLine("Enter username: ");
                        user_username = Console.ReadLine();
                        // open the connection with the database for making the query everytime
                        conn.Open();

                        // Now, we take our open connection and the query and turn it into a command
                        // reader will read the entries from first to last; it does this by setting reader equal to cmd.executereader();
                        query = "SELECT USERNAME FROM USERS WHERE USERNAME = @user_username";
                        // cmd is a command actually doing the query with the open connection
                        cmd = new MySqlCommand(query, conn);
                        // in the query the C# variable user_username is used, so Parameters.AddWithValue binds the two together
                        cmd.Parameters.AddWithValue("@user_username", user_username);
                        // reader is used to actually read values from the database
                        reader = cmd.ExecuteReader();
                        // while loop is used for when the reader is actually reading values 
                        while (reader.Read())
                        {
                            // reader.GetString(0) is the value in the first column, and GetString converts that to a string
                            if (user_username == reader.GetString(0))
                            {
                                hasAccess = true;
                            }
                        }

                        // when that one query is done, make sure to close the connection
                        conn.Close();

                    } while (!hasAccess);
                    

                    if (hasAccess)
                    {
                        hasAccess = false;
                        do {
                            Console.WriteLine("Enter password: ");
                            user_password = Console.ReadLine();
                            conn.Open();

                            // Now, we take our open connection and the query and turn it into a command
                            // reader will read the entries from first to last; it does this by setting reader equal to cmd.executereader();
                            query = "SELECT PASSWORD FROM USERS WHERE PASSWORD = @user_password";
                            cmd = new MySqlCommand(query, conn);
                            cmd.Parameters.AddWithValue("@user_password", user_password);
                            reader = cmd.ExecuteReader();
                            while (reader.Read())
                            {
                                if (user_username == reader.GetString(0))
                                {
                                    // hasAccess wil be set to true so user can continue with the rest of the program
                                    hasAccess = true;
                                }
                            }

                            conn.Close();
                        }
                        while (!hasAccess);
                    }


                    break;

                case 2:
                    conn.Open();
                    Console.WriteLine("Enter your first name: ");
                    user_fname = Console.ReadLine();
                    Console.WriteLine("Enter your last name: ");
                    user_lname = Console.ReadLine();
                    Console.WriteLine("Enter your username: ");
                    user_username = Console.ReadLine();
                    Console.WriteLine("Enter your password: ");
                    user_password = Console.ReadLine();
                    Console.WriteLine("Enter your email: ");
                    user_email = Console.ReadLine();
                    // our query is a string in C# but we will write it as a mysql query and pass it in
                    query = "INSERT INTO USERS (FNAME, LNAME, USERNAME, PASSWORD, EMAIL) VALUES(@user_fname, @user_lname, @user_username, @user_password, @user_email);";
                    // Create the command you want to execute by passing through your query and connection
                    cmd = new MySqlCommand(query, conn);
                    // We use a cmd.Paramaters.AddWithValue to bind the @fName to the fName variable that was assigned when the user inputted the information
                    cmd.Parameters.AddWithValue("@user_fName", user_fname);
                    cmd.Parameters.AddWithValue("@user_lName", user_lname);
                    cmd.Parameters.AddWithValue("@user_username", user_username);
                    cmd.Parameters.AddWithValue("@user_password", user_password);
                    cmd.Parameters.AddWithValue("@user_email", user_email);
                    // We then run an ExecuteNonQuery() since we are executing our command we created,
                    // but it's a NonQuery since we are not expecting anything back from the database
                    cmd.ExecuteNonQuery();

                    conn.Close();

                    // hasAccess wil be set to true so user can continue with the rest of the program
                    hasAccess = true;
                    
                    break;
            }

            if (hasAccess)
            {
                conn.Open();
                // this query will get the first name of the user using the username attained above
                query = "select fname from users where username=@user_username";
                cmd= new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@user_username", user_username);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    // get the first name of the user
                    user_fname = reader.GetString(0);
                }

                conn.Close();

                // use the first name to make a great UX
                Console.WriteLine("WELCOME, " + user_fname + "!");
                Console.WriteLine();
                Console.WriteLine("ID: --------------------------------------------------------------");

                // do while loop will run until the user chooses 2, which means they do not want to continue shopping and want to check out
                do
                {
                    //you must open the connection to be able to execute any query... if you don't it won't work
                    conn.Open();

                    //a string containing the mysql query we wanna execute
                    query = "select id, name, price, department, description from products";

                    //now, we take our open connection and the query and turn it into a command
                    cmd = new MySqlCommand(query, conn);

                    // use reader to read values
                    reader = cmd.ExecuteReader();

                    // while there is data to read it will keep looping
                    while (reader.Read())
                    {
                        // output the products and their values
                        Console.WriteLine(reader["id"] + "\t" + reader["name"] + "\t$" + reader["price"] + "\t" + reader["department"] + "\n\t" + reader["description"]);
                        Console.WriteLine();
                    }

                    conn.Close();

                    // a int variable for the product the user wants to buy
                    int product_choice = 1;
                    // a int variable for the quantity of that product they want to buy
                    int quantity;
                    // product price is initialized to 0 but will be found using mySQL
                    double product_price = 0;

                    // ask the user to enter the product ID
                    Console.WriteLine("Enter PRODUCT ID of which item you want: ");
                    do
                    {
                        product_choice = Convert.ToInt32(Console.ReadLine());

                    // 4 and 28 correspond to the product ids
                    } while (product_choice < 4 && product_choice > 28);

                    conn.Open();

                    // find the price of that product choices
                    query = "select price from products where id=@product_choice";
                    cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@product_choice", product_choice);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        // converting what was found by reader to double for the variable
                        product_price = Convert.ToDouble(reader["price"]);
                    }

                    conn.Close();

                    // ask the user to enter the quantity and store tat in quantity variable
                    Console.WriteLine("Enter how much of that product you would like: ");
                    do
                    {
                        quantity = Convert.ToInt32(Console.ReadLine());

                    } while (quantity <= 0);

                    total_price += (quantity * product_price);

                    conn.Open();

                    cmd = new MySqlCommand(query, conn);

                    // this query will use variables already used to input the quantity
                    // and the rest of the fields by using the product choice variable
                    // inserting into current purchase will make it easier later on to select from in the final checkout screen
                    query = "insert into current_purchase (name, price, product_id, quantity)" +
                        "values( (Select name from products where id=@product_choice)," +
                        "(Select price from products where id=@product_choice)," +
                        "(Select id from products where id=@product_choice)," +
                        "@quantity)";

                    cmd = new MySqlCommand(query, conn);

                    cmd.Parameters.AddWithValue("@product_choice", product_choice);
                    cmd.Parameters.AddWithValue("@quantity", quantity);


                    // execute non query since we do not want anything from the user
                    cmd.ExecuteNonQuery();

                    conn.Close();


                    Console.WriteLine();
                    Console.WriteLine("Would you like to keep shopping? ");
                    Console.WriteLine("1) Keep Shopping");
                    Console.WriteLine("2) Check Out");
                    continueShopping = Convert.ToInt32(Console.ReadLine());

                } while (continueShopping != 2);

                conn.Open();

                Console.WriteLine();
                Console.WriteLine("CURERENT PURCHASE: ");

                // this query will output all of the items in current purcase table
                query = "select name, price, quantity from current_purchase";
                // executing the command
                cmd = new MySqlCommand(query, conn);
                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    // read the price quantity and name of everything from the current purchase
                    Console.WriteLine("\t");
                    Console.Write(Convert.ToString(reader["price"]));
                    Console.Write("  x ");
                    Console.Write(Convert.ToString(reader["quantity"]));
                    Console.Write("\t");
                    Console.Write(Convert.ToString(reader["name"]));
                    Console.Write("\t");

                }
                Console.WriteLine();
                Console.WriteLine();

                conn.Close();

                // display the current purchase with the total price
                Console.WriteLine("TOTAL:\t\t\t $" + total_price, "\n");

                int confirm_purchase = 0;

                Console.WriteLine();
                Console.WriteLine("Confirm purchase? ");
                Console.WriteLine("1 - YES");
                Console.WriteLine("2 - NO");

                confirm_purchase = Convert.ToInt32(Console.ReadLine());

                switch (confirm_purchase)
                {
                    case 1:
                        Console.WriteLine("CONFIRMED! Thank you for shopping with us!");

                        // for the date or purchase, use a datetime object and convert to string
                        DateTime purchase_date = DateTime.Now;
                        Convert.ToString(purchase_date);

                        conn.Open();

                        cmd = new MySqlCommand(query, conn);

                        // insert into the invoice table
                        query = "insert into invoice (customer_id, totalprice, dateofpurchase) values( " +
                            "(select id from users where username=@user_username)," +
                            "@total_price," +
                            "@purchase_date )";
                        cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@user_username", user_username);
                        cmd.Parameters.AddWithValue("@total_price", total_price);
                        cmd.Parameters.AddWithValue("@purchase_date", purchase_date);

                        // non query since nothing is expected from table
                        cmd.ExecuteNonQuery();

                        conn.Close();

                        conn.Open();

                        // delete the current purchase table because this table only held the items being bought up until purchase;
                        // now that those values are in the current_purchase, this tables values can be deleted
                        query = "delete from current_purchase";
                        cmd = new MySqlCommand(query, conn);
                        // non query since nothing is expected from table
                        cmd.ExecuteNonQuery();

                        conn.Close();

                        break;
                    case 2:
                        Console.WriteLine("Please start program to restart and login in again. Thanks! ");

                        conn.Open();

                        query = "delete from current_purchase";
                        cmd = new MySqlCommand(query, conn);
                        cmd.ExecuteNonQuery();

                        conn.Close();

                        break;


                }

            }

            
            Console.WriteLine();

            
            }
        }
    }

