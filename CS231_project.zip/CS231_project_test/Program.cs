﻿
// IMPORTANT!!! Right click your solution file >> Manage NuGet Packages... >> And install MySQL.Data by Oracle


/*
 This program will ask for the users username and password, and check if it exists in the table
if not, then create new account, else sign in.
Then, display all of the products, let the user choose a product and the quantity,
confirm price. then continue shopping until -1 is chosen.
Then print receipt, put the date of transaction, and store the invoice in database
 */

using System;
using MySql.Data.MySqlClient; // Import Statement for connecting C# to MySQL client
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS231_project_test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Four variables to create the connection string
            string server = "localhost"; // If not using a cloud database, use localhost. If using cloud database, use the IP to the server
            string database = "online_store"; // Whatever database you want use for the application
            string username = "root"; // The username of your MySQL client
            string password = "PWL622002!"; // The password of your MySQL client

            // Throw all the variables into this connection string
            // MUST USE THIS FORMAT! (server, database, username, then password)
            string connstring = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + username + ";" + "PASSWORD=" + password + ";";

            //string userSelectionString;
            int userSelection = 0;

            string user_username;
            string user_password;
            string user_fname;
            string user_lname;
            string user_email;

            // Initializes the query string to be used for when you GET POST or DELETE
            string query;

            // The variables you will be using for inputs... you should use objects not just global variables...
            //string ID;
            //string fName;
            //string lName;
            //string username;
            //string password;
            //string email;

            // Initializes the connection object called "conn", using the connection string
            MySqlConnection conn = new MySqlConnection(connstring);

            // Initializes the command object called "cmd"
            MySqlCommand cmd;

            // Initializes the reader objected called "reader"
            MySqlDataReader reader;

            //Console.WriteLine("Here are all the users and their info: ");
            // You MUST open the connection to be able to execute any query... if you don't it won't work
            //conn.Open();
            // a string containing the mySQL query we wanna do
            //query = "SELECT * FROM USERS";
            // Now, we take our open connection and the query and turn it into a command
            //cmd = new MySqlCommand(query, conn);

            // reader will read the entries from first to last; it does this by setting reader equal to cmd.ExecuteReader();
            

            //// While there is data to read it will keep looping
            //while (reader.Read())
            //{
            //    Console.WriteLine(reader["id"]); // Row N ID... N indicates which row it is currently on
            //    Console.WriteLine(reader["fName"]); // You should assign these variables to an array of objects rather than write them to the console
            //    Console.WriteLine(reader["lName"]);
            //    Console.WriteLine(reader["username"]);
            //    Console.WriteLine(reader["password"]);
            //    Console.WriteLine(reader["email"]);
            //    Console.WriteLine();
            //}

            Console.WriteLine("Enter:\n\t1 - Login (Returning User)\n\t2 - Register\n");
            userSelection = Convert.ToInt32(Console.ReadLine());
    
            switch (userSelection) {
                case 1:
                    // TODO: Make this validation thing work
                    Console.WriteLine("Enter username: ");
                    user_username = Console.ReadLine();
                    conn.Open();
                    query = "SELECT USERNAME FROM USERS WHERE USERNAME = @user_username";
                    break;
                case 2:
                    conn.Open();
                    Console.WriteLine("Enter your first name: ");
                    user_fname = Console.ReadLine();
                    Console.WriteLine("Enter your last name: ");
                    user_lname = Console.ReadLine();
                    Console.WriteLine("Enter your username: ");
                    user_username = Console.ReadLine();
                    Console.WriteLine("Enter your password: ");
                    user_password = Console.ReadLine();
                    Console.WriteLine("Enter your email: ");
                    user_email = Console.ReadLine();
                    // our query is a string in C# but we will write it as a mysql query and pass it in
                    query = "INSERT INTO USERS (FNAME, LNAME, USERNAME, PASSWORD, EMAIL) VALUES(@user_fname, @user_lname, @user_username, @user_password, @user_email);";
                    // Create the command you want to execute by passing through your query and connection
                    cmd = new MySqlCommand(query, conn);
                    // We use a cmd.Paramaters.AddWithValue to bind the @fName to the fName variable that was assigned when the user inputted the information
                    cmd.Parameters.AddWithValue("@user_fName", user_fname);
                    cmd.Parameters.AddWithValue("@user_lName", user_lname);
                    cmd.Parameters.AddWithValue("@user_username", user_username);
                    cmd.Parameters.AddWithValue("@user_password", user_password);
                    cmd.Parameters.AddWithValue("@user_email", user_email);
                    // We then run an ExecuteNonQuery() since we are executing our command we created, but it's a NonQuery since we are not expecting anything back from the database
                    cmd.ExecuteNonQuery();
                    break;
            }


            Console.WriteLine("WELCOME, " + /*user_fname + */ "!");
            Console.WriteLine();
            Console.WriteLine("ID: --------------------------------------------------------------");

            //you must open the connection to be able to execute any query... if you don't it won't work
            
            //a string containing the mysql query we wanna execute
            query = "select id, name, price, department, description from products";

            //now, we take our open connection and the query and turn it into a command
            cmd = new MySqlCommand(query, conn);

            // reader will read the entries from first to last; it does this by setting reader equal to cmd.executereader();
            reader = cmd.ExecuteReader();

            //// creating an array to store all of the possible product ids
            //int[] product_ids = new int[25] ;
            //// makin a for loop to populate the array with the possible product ids
            //for(int i = 0; i < 25; i++)
            //{
            //    product_ids[i] = i+4;
            //}

            // while there is data to read it will keep looping
            while (reader.Read())
            {
                Console.WriteLine(reader["id"] + "\t" + reader["name"] + "\t$" + reader["price"] + "\t" + reader["department"] + "\n\t" + reader["description"]);
                Console.WriteLine();
            }

            // a int variable for the product the user wants to buy
            int product_choice;
            // a int variable for the quantity of that product they want to buy
            int quantity;
            //
            double product_price;
            //
            double selection_price = 0;

            // ask the user to enter the product ID
            Console.WriteLine("Enter PRODUCT ID of which item you want: ");
            do
            {
                product_choice = Convert.ToInt32(Console.ReadLine());

            } while(product_choice < 4 && product_choice > 28);

            // product_price = "Select price from products where id=product_choice;

            // ask the user to enter the quantity and store tat in quantity variable
            Console.WriteLine("Enter how much of that product you would like: ");
            do
            {
                quantity = Convert.ToInt32(Console.ReadLine());

            } while (quantity <= 0);

            query = "Select price from products where id=@product_choice";

            cmd = new MySqlCommand(query, conn);

            product_price = Convert.ToDouble(reader["price"]);

            selection_price += (quantity * product_price);
            query = "insert into current_purchase (name, price, product_id, quantity, total_price) values( (Select name from products where id=@product_choice), (Select price from products where id=@product_choice), (Select product from products where id=@product_choice), @quantity, @selection_price)";


            Console.WriteLine("CURERENT PURCHASE: ");
            //a string containing the mysql query we wanna execute
            query = "select id, name, price, product_id, quantity, selection_price from current_purchase";
            // executing the command
            cmd = new MySqlCommand(query, conn);
            //TODO:
            // fix this errror!
            Console.WriteLine(Convert.ToString(reader["id"]), " ", reader["name"], " ", reader["price"], "*", reader["quantity"], " = ", reader["selection_price"]);

            /*
             * At the end of the program, 
             * select * from current_purchase
             * ask user for confirmation of purchase
             * then insert that (select * from current_purchase) into invoice
             * and then clear the [temporary] current_purchase table
             */

            conn.Close();



            //while (userSelection != 4)
            //{

            //    Console.WriteLine("Choose an option...");
            //    Console.WriteLine("1) Insert into database");
            //    Console.WriteLine("2) Remove from database");
            //    Console.WriteLine("3) View data from database");
            //    Console.WriteLine("4) Exit from interface");

            //    userSelectionString = Console.ReadLine();
            //    userSelection = Convert.ToInt32(userSelectionString);

            //    switch (userSelection)
            //    {
            //        case 1:
            //            Console.WriteLine("First name:");
            //            fName = Console.ReadLine();
            //            Console.WriteLine("Last name:");
            //            lName = Console.ReadLine();
            //            Console.WriteLine("Phone number:");
            //            phone = Console.ReadLine();
            //            Console.WriteLine("State:");
            //            state = Console.ReadLine();

            //            // You MUST open the connection to be able to execute any query... if you don't it won't work
            //            conn.Open();

            //            // Set your query to whatever SQL query you want... in this case we are doing an INSERT statement.
            //            // Notice I use an @ symbol each time for the values we input into the datase...
            //            query = "INSERT INTO students(fName, lName, phone, state) VALUES (@fName, @lName, @phone, @state)";

            //            // Create the command you want to execute by passing through your query and connection
            //            cmd = new MySqlCommand(query, conn);

            //            // We use a cmd.Paramaters.AddWithValue to bind the @fName to the fName variable that was assigned when the user inputted the information
            //            cmd.Parameters.AddWithValue("@fName", fName);
            //            cmd.Parameters.AddWithValue("@lName", lName);
            //            cmd.Parameters.AddWithValue("@phone", phone);
            //            cmd.Parameters.AddWithValue("@state", state);

            //            // We then run an ExecuteNonQuery() since we are executing our command we created, but it's a NonQuery since we are not expecting anything back from the database
            //            cmd.ExecuteNonQuery();

            //            // Lastly we MUST close the connection because connections are limited relatively expensive resource
            //            conn.Close();

            //            Console.WriteLine("Person has been inserted into the datbase.");

            //            break;

            //        case 2:
            //            Console.WriteLine("Which person would you like to remove? Enter an ID.");
            //            ID = Console.ReadLine();

            //            conn.Open();
            //            query = "DELETE FROM students WHERE id = @ID";
            //            cmd = new MySqlCommand(query, conn);
            //            cmd.Parameters.AddWithValue("@id", ID);
            //            cmd.ExecuteNonQuery();
            //            conn.Close();

            //            Console.WriteLine("Person has beem removed from the database.");

            //            break;

            //        case 3:
            //            Console.WriteLine("Here are the people in the database.");

            //            conn.Open();
            //            query = "SELECT * FROM students";
            //            cmd = new MySqlCommand(query, conn);

            //            // We set the reader variable to cmd.ExecuteReader() so it can read the entries of the table it receives from first to last
            //            reader = cmd.ExecuteReader();

            //            // While there is data to read it will keep looping
            //            while (reader.Read())
            //            {
            //                Console.WriteLine(reader["id"]); // Row N ID... N indicates which row it is currently on
            //                Console.WriteLine(reader["fName"]); // You should assign these variables to an array of objects rather than write them to the console
            //                Console.WriteLine(reader["lName"]);
            //                Console.WriteLine(reader["phone"]);
            //                Console.WriteLine(reader["state"]);
            //                Console.WriteLine();
            //            }
            //            conn.Close();
            //            break;
            //        case 4:
            //            break;
            //        default:
            //            Console.WriteLine("Invalid Selection. Choose again.");
            //            break;
            //    }

            Console.WriteLine();

            
            }
        }
    }

